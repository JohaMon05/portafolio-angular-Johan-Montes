Este proyecto fue realizado con angular, haciendo uso de lenguaje typescrypt

Este proyecto es basicamente un portafolio, pensado para que en el se usen 
mecanismos de refresco automatico de la pagina

La estetica no es de una pagina muy detallada, puesto que el verdadero objetivo
era que estuviera acorde con mi personalidad, y con uno de mis pasatiempos 
favoritos como son los videojuegos

Una funcionalidad adicional, que es el verdadero punto fuerte de este proyecto es 
una consulta de informacion y datos a poke Api, un sitio con informacion general 
de todos los pokemon registrados en ella

Uno de los requisitos de este trabajo era justamente realizar una consulta a poke Api
y lo que hice fue consultar los pokemon de determinado tipo dentro del limite de 
pokemon que el usuario establezca previamente

Dentro de este proyecto podran encontrar informacion basica mia como programador
experiencia, proyectos en los que he estado, datos personales y mi contacto|
