import { Routes } from '@angular/router';
import { LandingPage } from './components/landing-page/landing-page';
import { AboutMe } from './components/about-me/about-me';
import { NotFound } from './components/not-found/not-found';
import { PokemonTable } from './components/pokemon-table/pokemon-table';
import { Experiencia } from './components/experiencia/experiencia';
import { Contacto } from './components/contacto/contacto';
import { Proyectos } from './components/proyectos/proyectos';
export const routes: Routes = [
    {
        path: '',
        component: LandingPage
    },
    {
        path: 'about-me',
        component: AboutMe
    },
    {
        path: 'pokemon-table',
        component: PokemonTable
    },
    {
        path: 'experiencia',
        component: Experiencia
    },
    {
        path: 'contacto',
        component: Contacto
    },
    {
        path: 'proyectos',
        component: Proyectos
    },
    {
        path: '**',
        component: NotFound
    }
    
];
