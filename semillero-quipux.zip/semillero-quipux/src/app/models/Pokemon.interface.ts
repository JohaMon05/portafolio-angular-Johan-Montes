export interface Pokemon {
  name: string;
  url: string;
  image?: string;
  types: {
    slot: number;
    type: {
      name: string;
      url: string;
    };
  }[];
}