import { Pokemon } from "./Pokemon.interface";

export interface PokemonInterface {
    count: number,
    results: Pokemon[]
}