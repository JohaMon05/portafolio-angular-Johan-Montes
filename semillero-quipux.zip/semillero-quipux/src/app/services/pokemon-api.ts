import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, forkJoin, map, switchMap } from 'rxjs';
import { Pokemon } from '../models/Pokemon.interface';

@Injectable({
  providedIn: 'root'
})
export class PokemonApi {
  private apiUrl = 'https://pokeapi.co/api/v2/';

  constructor(private http: HttpClient) {}

  getPokemons(limit: number, offset: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}pokemon?limit=${limit}&offset=${offset}`);
  }

  getPokemonsWithTypes(limit: number, offset: number): Observable<Pokemon[]> {
    return this.getPokemons(limit, offset).pipe(
      switchMap(response => {
        const pokemonRequests = response.results.map((pokemon: any) =>
          this.http.get<any>(pokemon.url).pipe(
            map(details => ({
              name: pokemon.name,
              url: pokemon.url,
              image: details.sprites.front_default,
              types: details.types
            }))
          )
        );
        return forkJoin<Pokemon[]>(pokemonRequests);

      })
    );
  }
}