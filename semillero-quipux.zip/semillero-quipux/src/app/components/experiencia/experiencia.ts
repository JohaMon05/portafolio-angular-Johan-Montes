import { Component } from '@angular/core';

@Component({
  selector: 'app-experiencia',
  imports: [],
  templateUrl: './experiencia.html',
  styleUrl: './experiencia.css'
})
export class Experiencia {

}
