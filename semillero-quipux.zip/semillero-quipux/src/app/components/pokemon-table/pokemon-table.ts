import { Component } from '@angular/core';
import { PokemonApi } from '../../services/pokemon-api';
import { CommonModule } from '@angular/common';
import { Pokemon } from '../../models/Pokemon.interface';
import { FormsModule } from '@angular/forms';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-pokemon-table',
  imports: [CommonModule, FormsModule],
  templateUrl: './pokemon-table.html',
  styleUrl: './pokemon-table.css'
})
export class PokemonTable {

  pokemons: Pokemon[] | null = null;
  pokemonsOriginales: Pokemon[] = [];
  limit: number = 10;
  offset: number = 0;
  tiposeleccionado: string = 'Ninguna';

  constructor(private pokemonService: PokemonApi) {}

  ngOnInit() {
    console.log("Método que se ejecuta cuando carga el componente.");
  }

  buscarPokemons(): void {
    if (this.limit < 1) {
      Swal.fire({
        title: 'Error!',
        text: 'Por favor, digite un límite válido mayor que 0',
        icon: 'error',
        confirmButtonText: 'Cool'
      });
      return;
    }

    this.pokemonService.getPokemonsWithTypes(this.limit, this.offset).subscribe({
      next: (data) => {
        this.pokemonsOriginales = data;
        this.filtrarPokemons();
      },
      error: (err: any) => {
        console.error('Error al consultar los pokemons ', err);
      }
    });
  }

  filtrarPokemons(): void {
    if (this.tiposeleccionado === 'Ninguna') {
      this.pokemons = this.pokemonsOriginales;
    } else {
      this.pokemons = this.pokemonsOriginales.filter(p =>
        p.types.some(t => t.type.name.toLowerCase() === this.tiposeleccionado.toLowerCase())
      );
    }
  }
}